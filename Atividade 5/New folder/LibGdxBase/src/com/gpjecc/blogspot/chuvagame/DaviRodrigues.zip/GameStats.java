package com.gpjecc.blogspot.chuvagame;

public class GameStats {
    public int vidas;
    public int pontos;

    public GameStats(int vidas, int pontos) {
        this.vidas = vidas;
        this.pontos = pontos;
    }
}
