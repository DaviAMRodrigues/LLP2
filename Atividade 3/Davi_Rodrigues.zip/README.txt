# Atividade 3

Este projeto foi desenvolvido pelo aluno **Davi Augusto Marçal Rodrigues** da turma **Informatica 3** no dia **10/04/2025** como parte das atividades da disciplina LLP2.

## Descrição

Este repositório contém os arquivos relacionados à Atividade 3. O objetivo principal é aplicar os conceitos de POO aprendidos em aula para resolver os problemas propostos.

## Autor

- **Davi Augusto Marçal Rodrigues**