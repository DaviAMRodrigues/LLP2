package zoo;

public class Mamifero extends Animal {
    
    public Mamifero() {
        super();
    }
    
    public void mamar() {
        System.out.println("xuc, xuc, xuc");
    }
    
    public void emitirSom() {
        System.out.println("Inominado diz: zzzzzzzzzzzzz!!!");
    }
    
}
