package zoo;

public class Vaca extends Mamifero {
    
    public Vaca() {
        super();
    }
    
    public void mamar() {
        System.out.println("xuc, xuc, xuc");
    }
    
    public void emitirSom() {
        System.out.println("MUUUUUU!!");
    }
    
}
