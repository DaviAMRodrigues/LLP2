package dao;

import modelo.Musica;

import java.util.List;

public interface MusicaDAO {
  public List<Musica> getAllMusicas();
}