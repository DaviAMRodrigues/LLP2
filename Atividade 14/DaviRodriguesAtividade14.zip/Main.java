import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

public class Main {
    public static void main(String[] args) {
        LerCSV lerCSV = new LerCSV();
        ArrayList<Aluno> alunos = lerCSV.LerCSV();

        if (alunos != null) {
            for (Aluno aluno : alunos) {
                System.out.println(aluno);
            }
        } else {
            System.out.println("Erro ao ler o arquivo CSV.");
        }

        Janela janela = new Janela();
        Aluno alunoLido = new Aluno();
        JFrame frame1 = new JFrame("Cadastrar ou Ler Aluno");
        JFrame frame2 = new JFrame("Update ou Excluir Aluno");
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setSize(400, 300);
        frame1.setLayout(null);
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame2.setSize(400, 300);
        frame2.setLayout(null);
        

        janela.getLabelNumero().setBounds(10, 40, 80, 25);
        janela.getTextFieldNumero().setBounds(100, 40, 160, 25);
        janela.getLabelMatricula().setBounds(10, 70, 80, 25);
        janela.getTextFieldMatricula().setBounds(100, 70, 160, 25);
        janela.getLabelNome().setBounds(10, 100, 80, 25);
        janela.getTextFieldNome().setBounds(100, 100, 160, 25);
        janela.getButtonCreate().setBounds(10, 130, 250, 25);
        janela.getButtonRead().setBounds(10, 160, 250, 25);
        janela.getButtonUpdate().setBounds(10, 130, 250, 25);
        janela.getButtonDelete().setBounds(10, 160, 250, 25);

        frame1.add(janela.getLabelNumero());
        frame1.add(janela.getTextFieldNumero());
        frame1.add(janela.getLabelMatricula());
        frame1.add(janela.getTextFieldMatricula());
        frame1.add(janela.getLabelNome());
        frame1.add(janela.getTextFieldNome());
        frame1.add(janela.getButtonCreate());
        frame1.add(janela.getButtonRead());
        frame1.setVisible(true);


        janela.getButtonCreate().addActionListener(e -> {
            int numero = Integer.parseInt(janela.getTextFieldNumero().getText());
            String matricula = janela.getTextFieldMatricula().getText();
            String nome = janela.getTextFieldNome().getText();
            Aluno novoAluno = new Aluno(numero, matricula, nome);
            alunos.add(novoAluno);
            lerCSV.escreverCSV(alunos);
            JOptionPane.showMessageDialog( null, "Aluno Criado", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
        });

        janela.getButtonRead().addActionListener(e -> {
            int numero = Integer.parseInt(janela.getTextFieldNumero().getText());
            String matricula = janela.getTextFieldMatricula().getText();
            String nome = janela.getTextFieldNome().getText();
            Aluno novoAluno = new Aluno(numero, matricula, nome);
            Boolean alunoEncontrado = false;
            for (Aluno aluno : alunos) {
                if (aluno.getNumero() == novoAluno.getNumero() &&
                    aluno.getMatricula().equals(novoAluno.getMatricula()) && 
                    aluno.getNome().equals(novoAluno.getNome())) {
                    alunoEncontrado = true;
                    System.out.println("Aluno encontrado: " + aluno);
                    alunoLido.setNumero(aluno.getNumero());
                    alunoLido.setMatricula(aluno.getMatricula());
                    alunoLido.setNome(aluno.getNome());

                    frame1.setVisible(false);

                    JLabel label = new JLabel("Aluno encontrado:");
                    label.setBounds(10, 10, 200, 25);
                    JLabel labelNome = new JLabel(aluno.getNome());
                    labelNome.setBounds(120, 10, 200, 25);
                    frame2.add(label);
                    frame2.add(labelNome);
                    janela.getLabelNumero().setText("Novo Numero");
                    frame2.add(janela.getLabelNumero());
                    frame2.add(janela.getTextFieldNumero());
                    janela.getLabelMatricula().setText("Nova Matrícula");
                    frame2.add(janela.getLabelMatricula());
                    frame2.add(janela.getTextFieldMatricula());
                    janela.getLabelNome().setText("Novo Nome");
                    frame2.add(janela.getLabelNome());
                    frame2.add(janela.getTextFieldNome());
                    frame2.add(janela.getButtonUpdate());
                    frame2.add(janela.getButtonDelete());
                    frame2.setVisible(true);
                    break;
                }
            }
            if (alunoEncontrado == false) {
                JOptionPane.showMessageDialog( null, "Aluno não encontrado", "Erro", JOptionPane.WARNING_MESSAGE);
            }
        });

        janela.getButtonUpdate().addActionListener(e -> {
            boolean alunoEncontrado = false;
            for (Aluno aluno : alunos) {
                if (aluno.getNumero() == alunoLido.getNumero() &&
                    aluno.getMatricula().equals(alunoLido.getMatricula()) &&
                    aluno.getNome().equals(alunoLido.getNome())) {
                    aluno.setNumero(Integer.parseInt(janela.getTextFieldNumero().getText()));
                    aluno.setMatricula(janela.getTextFieldMatricula().getText());
                    aluno.setNome(janela.getTextFieldNome().getText());
                    lerCSV.escreverCSV(alunos);
                    alunoLido.setNumero(aluno.getNumero());
                    alunoLido.setMatricula(aluno.getMatricula());  
                    alunoLido.setNome(aluno.getNome());
                    
                    alunoEncontrado = true;
                    JOptionPane.showMessageDialog( null, "Aluno alterado", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
                    break;
                }
            }
            if (alunoEncontrado == false) {
                JOptionPane.showMessageDialog( null, "Aluno não encontrado", "Erro", JOptionPane.WARNING_MESSAGE);
            }
        });

        janela.getButtonDelete().addActionListener(e -> {
            Aluno alunoParaExcluir = null;
            for (Aluno aluno : alunos) {
                if (aluno.getNumero() == alunoLido.getNumero() &&
                    aluno.getMatricula().equals(alunoLido.getMatricula()) &&
                    aluno.getNome().equals(alunoLido.getNome())) {
                    alunoParaExcluir = aluno;
                    break;
                }
            }
            if (alunoParaExcluir != null) {
                alunos.remove(alunoParaExcluir);
                lerCSV.escreverCSV(alunos);
                JOptionPane.showMessageDialog( null, "Aluno Deletado", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog( null, "Aluno não encontrado", "Erro", JOptionPane.WARNING_MESSAGE);
            }
        });
        
    }
}
