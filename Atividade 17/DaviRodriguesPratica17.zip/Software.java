public class Software extends Gravacao{
    public int versao;
    public String plataforma;
    @Override
    public String toString() {
        return super.toString()  + versao + ";" + plataforma;
    }
    public Software(int numeroCatalogo, int numeroDeCopias,  String titulo, String midia, int versao, String plataforma) {
        super(numeroCatalogo, numeroDeCopias, titulo, midia);
        this.versao = versao;
        this.plataforma = plataforma;
    }
}
