public abstract class Biblioteca {

    protected int numeroCatalogo;
    protected int numeroDeCopias;

    public void adiquirir(){
    }

    public void retornar(){
    }

    @Override
    public String toString() {
        return  numeroCatalogo + ";" + numeroDeCopias;
    }

    public Biblioteca(int numeroCatalogo, int numeroDeCopias) {
        this.numeroCatalogo = numeroCatalogo;
        this.numeroDeCopias = numeroDeCopias;
    }
    
}