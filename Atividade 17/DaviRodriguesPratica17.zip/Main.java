import java.time.LocalDate;
import java.util.ArrayList;

import javax.swing.SwingUtilities;

public class Main {

    public static void itemInfo(Biblioteca biblioteca){
        System.out.println(biblioteca.toString());
    }

    public static void main(String[] args) {

        ArrayList<Biblioteca> bibliotecas = new ArrayList<>();

        bibliotecas.add(new Filme(0, 0, null, null, null, null, null));
        itemInfo(bibliotecas.get(0));

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new InterfaceGerada().setVisible(true);
            }
        });
    }
}
