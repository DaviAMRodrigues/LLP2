import javax.swing.*;
import javax.swing.event.*;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

public class InterfaceGerada extends JFrame {
    private JTextField nCatalogo;
    private JTextField nCopias;
    private JTextField Titulo;
    private JTextField Midia;
    private JCheckBox chkFilme;
    private JCheckBox chkSoftware;
    private JTextField Diretor;
    private JTextField data_de_Lancamento;
    private JTextField Distribuidor;
    private JTextField Version;
    private JTextField Plataforma;
    private JButton Adicionar;
    private JButton Limpar;
    private JPanel panelCampos;
    private ArrayList<Biblioteca> bibliotecas = new ArrayList<>();

    public InterfaceGerada() {
        initComponents();
        setupLayout();
        setupEvents();
    }
    
    private void initComponents() {
        nCatalogo = new JTextField(20);
        nCopias = new JTextField(20);
        Titulo = new JTextField(20);
        Midia = new JTextField(20);
        chkFilme = new JCheckBox("Filme");
        chkSoftware = new JCheckBox("Software");
        Diretor = new JTextField(20);
        data_de_Lancamento = new JTextField(20);
        Distribuidor = new JTextField(20);
        Version = new JTextField(20);
        Plataforma = new JTextField(20);
        Adicionar = new JButton("Adicionar");
        Limpar = new JButton("Limpar");
    }
    
    private void setupLayout() {
        setTitle("Interface Gerada");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        // Painel para campos de texto
        panelCampos = new JPanel();
        panelCampos.setLayout(new BoxLayout(panelCampos, BoxLayout.Y_AXIS));
        panelCampos.setLayout(new BoxLayout(panelCampos, BoxLayout.Y_AXIS));

        // Campo Titulo
        JPanel panelCatalogo = new JPanel();
        panelCatalogo.add(new JLabel("Numero Catalogo:"));
        panelCatalogo.add(nCatalogo);
        panelCampos.add(panelCatalogo);

        // Campo Titulo
        JPanel panelCopias = new JPanel();
        panelCopias.add(new JLabel("Numero De Copias:"));
        panelCopias.add(nCopias);
        panelCampos.add(panelCopias);

        // Campo Titulo
        JPanel panelTitulo = new JPanel();
        panelTitulo.add(new JLabel("Titulo:"));
        panelTitulo.add(Titulo);
        panelCampos.add(panelTitulo);
        
        // Campo Midia
        JPanel panelMidia = new JPanel();
        panelMidia.add(new JLabel("Midia:"));
        panelMidia.add(Midia);
        panelCampos.add(panelMidia);
        
        // Campo a
        JPanel panelSelecao = new JPanel();
        panelSelecao.add(chkFilme);
        panelSelecao.add(chkSoftware);
        panelCampos.add(panelSelecao);
        
        // Campo Diretor
        JPanel panelDiretor = new JPanel();
        panelDiretor.add(new JLabel("Diretor:"));
        panelDiretor.add(Diretor);
        panelCampos.add(panelDiretor);
        
        // Campo Data de Lancamento
        JPanel panelData_De_Lancamento = new JPanel();
        panelData_De_Lancamento.add(new JLabel("Data De Lancamento:"));
        panelData_De_Lancamento.add(data_de_Lancamento);
        panelCampos.add(panelData_De_Lancamento);
        
        // Campo Distribuidor
        JPanel panelDistribuidor = new JPanel();
        panelDistribuidor.add(new JLabel("Distribuidor:"));
        panelDistribuidor.add(Distribuidor);
        panelCampos.add(panelDistribuidor);
        
        // Campo Version
        JPanel panelVersion = new JPanel();
        panelVersion.add(new JLabel("Version:"));
        panelVersion.add(Version);
        panelCampos.add(panelVersion);
        
        // Campo Plataforma
        JPanel panelPlataforma = new JPanel();
        panelPlataforma.add(new JLabel("Plataforma:"));
        panelPlataforma.add(Plataforma);
        panelCampos.add(panelPlataforma);
        
        add(panelCampos);

        // Painel para botões
        JPanel panelBotoes = new JPanel();
        panelBotoes.add(Adicionar);
        panelBotoes.add(Limpar);
        add(panelBotoes);

        pack();
        setLocationRelativeTo(null);
    }
    
    private void setupEvents() {
        Adicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ação do botão Adicionar

                
                Biblioteca biblioteca = null;

                if (chkFilme.isSelected()) {
                    biblioteca = new Filme(
                        Integer.parseInt(nCatalogo.getText()),
                        Integer.parseInt(nCopias.getText()),
                        Titulo.getText(), 
                        Midia.getText(), 
                        Diretor.getText(), 
                        LocalDate.parse(data_de_Lancamento.getText()), 
                        Distribuidor.getText()
                    );
                    bibliotecas.add(biblioteca);
                
                } else if (chkSoftware.isSelected()) {
                    biblioteca = new Software(
                        Integer.parseInt(nCatalogo.getText()),
                        Integer.parseInt(nCopias.getText()),
                        Titulo.getText(), 
                        Midia.getText(), 
                        Integer.parseInt(Version.getText()), 
                        Plataforma.getText()
                    );
                    bibliotecas.add(biblioteca);
                }

                JOptionPane.showMessageDialog(InterfaceGerada.this, 
                    "Botão Adicionar foi clicado!");
            }
        });
        
        Limpar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                for (Component component : panelCampos.getComponents()) {
                    if (component instanceof JPanel) {
                        JPanel panel = (JPanel) component;
                        for (Component subComponent : panel.getComponents()) {
                            if (subComponent instanceof JTextField) {
                                ((JTextField) subComponent).setText("");
                            } else if (subComponent instanceof JCheckBox) {
                                ((JCheckBox) subComponent).setSelected(false);
                            }
                        }
                    }
                }

                JOptionPane.showMessageDialog(InterfaceGerada.this, 
                    "Botão Limpar foi clicado!");
            }
        });
        
    }

    private void escreverDados() throws IOException{
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("Dados.txt"))) {
            for (Biblioteca biblioteca : bibliotecas) {
                bw.write(biblioteca.toString());
                bw.newLine();
            }
        }
    }

    @Override
    protected void processWindowEvent(WindowEvent e) {
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            try {
                escreverDados();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        super.processWindowEvent(e);
    }
}