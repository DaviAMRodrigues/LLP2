public class Publicacao extends Biblioteca{
    private String titulo;
    private String editor;
    @Override
    public String toString() {
        return ";" + titulo + ";" + editor;
    }
    public Publicacao(int numeroCatalogo, int numeroDeCopias, String titulo, String editor) {
        super(numeroCatalogo, numeroDeCopias);
        this.titulo = titulo;
        this.editor = editor;
    }
}
