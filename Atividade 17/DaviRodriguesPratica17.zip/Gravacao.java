public class Gravacao extends Biblioteca {
    protected String titulo;
    protected String midia;
    @Override
    public String toString() {
        return super.toString() + ";" + titulo + ";" + midia;
    }
    public Gravacao(int numeroCatalogo, int numeroDeCopias, String titulo, String midia) {
        super(numeroCatalogo, numeroDeCopias);
        this.titulo = titulo;
        this.midia = midia;
    }
    
}
