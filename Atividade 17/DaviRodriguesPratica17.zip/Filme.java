import java.time.LocalDate;

public class Filme extends Gravacao{
    public String diretor;
    public LocalDate dataLancamento;
    public String distribuidor;
    @Override
    public String toString() {
        return super.toString() + ";" + diretor + ";" + dataLancamento + ";" + distribuidor;
    }
    public Filme(int numeroCatalogo, int numeroDeCopias, String titulo, String midia, String diretor, LocalDate dataLancamento,
            String distribuidor) {
        super(numeroCatalogo, numeroDeCopias, titulo, midia);
        this.diretor = diretor;
        this.dataLancamento = dataLancamento;
        this.distribuidor = distribuidor;
    }
}
