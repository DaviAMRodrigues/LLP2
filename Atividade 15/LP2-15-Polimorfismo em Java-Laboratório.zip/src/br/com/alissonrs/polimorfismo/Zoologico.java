package br.com.alissonrs.polimorfismo;


public class Zoologico {

	public static void main(String[] args) {
		Mamifero mama;
		Cachorro cachorro;
		Vaca vaca;

		mama = new Mamifero();
		cachorro = new Cachorro("Snoopy");
		vaca = new Vaca();

		mama.mamar();
		cachorro.mamar();
		vaca.mamar();

		mama.emitirSom();
		cachorro.emitirSom();
		vaca.emitirSom();
	}
	
	

}