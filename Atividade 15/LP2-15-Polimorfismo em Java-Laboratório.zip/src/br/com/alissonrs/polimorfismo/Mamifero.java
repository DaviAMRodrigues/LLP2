package br.com.alissonrs.polimorfismo;

public class Mamifero extends Animal {
	public void mamar() {
		System.out.println("xuc, xuc, xuc");
	}
}
